const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
const vendorRoutes = require('./routes/vendor');
const productRoutes = require('./routes/product');
const orderRoutes = require('./routes/order');

const app = express();
const port = 3000;

mongoose.connect('mongodb://localhost/ecommerce', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Could not connect to MongoDB', err));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use('/vendor', vendorRoutes);
app.use('/product', productRoutes);
app.use('/order', orderRoutes);

app.get('/', (req, res) => {
  res.render('dashboard');
});

app.listen(port, () => {
  console.log(Server running at http://localhost:${port});
});